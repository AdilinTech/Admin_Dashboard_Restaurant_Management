import React from 'react'
import { BiSolidFileJson } from 'react-icons/bi';
import PurchaseRequestForm from '../../../../components/bhojanNewAppMRN/purchaseRequests/editReuest/editRequestPurcahse';


function  EditRequestPurchase() {
  return (
  
  <div className='card'style={{marginTop: "10px", marginLeft: "4px", marginRight: "4px"}}>
        <div className='table-responsive active-projects style-1' >
      <h3 className='tbl-caption text-light'>
      Edit Request For Purchase 









    <div>
      </div>
      </h3> </div>  
      <PurchaseRequestForm/>  
      </div>
      
     


)
}

export default EditRequestPurchase ;  